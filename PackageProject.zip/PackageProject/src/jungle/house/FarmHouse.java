package jungle.house;

import jungle.cave.Bear;
import jungle.cave.Tiger;
import jungle.cave.WhiteTiger;

class FarmHouse {
	public static void main(String[] args) {
		System.out.println("Begin main");
		Tiger tiger = new Tiger();
		tiger.jump();
		
		WhiteTiger wt = new WhiteTiger();
		wt.jump();
		
		Bear b = new Bear();
		b.eatHoney();
		System.out.println("End main");
	}
}
