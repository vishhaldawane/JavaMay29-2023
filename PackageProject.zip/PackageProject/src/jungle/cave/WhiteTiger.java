package jungle.cave;

public class WhiteTiger extends Tiger {
	public void jump() {
		System.out.println("WhiteTiger is jumping....");
	}
}