package jungle.tree;

import jungle.cave.Tiger;

public class Bear {
	Tiger t = new Tiger();
	public void eatHoney() {
		System.out.println("Bear is eating the honey...");
		System.out.println("Bear defaultA   : "+t.defaultA);
		System.out.println("Bear privateA   : "+t.privateA); //ERROR- 
		System.out.println("Bear protectedA : "+t.protectedA); //Bear is in the same package- then protected is avaialble, if diff package then not available
		System.out.println("Bear publicA    : "+t.publicA);
	
	}
}
