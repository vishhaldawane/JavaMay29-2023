package jungle.cave;

public class WhiteTiger extends Tiger { //CHILD CLASS 
	/*public void jump() {
		System.out.println("WhiteTiger is jumping....");
		System.out.println("WhiteTiger defaultA   : "+defaultA);
		//System.out.println("WhiteTiger privateA   : "+privateA); //ERROR- 
		System.out.println("WhiteTiger protectedA : "+protectedA);
		System.out.println("WhiteTiger publicA    : "+publicA);
	}*/
}