package jungle.cave;

//writing a public class does not mean the contents are public 
public class Tiger {
	           int defaultA=10;
	private    int privateA=20; //can only be referred by the declaring class
	protected  int protectedA=30;
	public     int publicA=40;
	
	public Tiger() {
		
	}
    public void jump() {
    	
		System.out.println("Tiger is jumping....");
		System.out.println("defaultA   : "+defaultA);
		System.out.println("privateA   : "+privateA);
		System.out.println("protectedA : "+protectedA);
		System.out.println("publicA    : "+publicA);
	}
}



