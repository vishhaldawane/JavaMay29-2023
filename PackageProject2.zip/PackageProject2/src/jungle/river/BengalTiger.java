package jungle.river;

import jungle.cave.Tiger;
//BengalTiger b = new BengalTiger();
//WhiteTiger w = new WhiteTiger();
//b.roar(w);
public class BengalTiger extends Tiger {
	public void jump() {
		System.out.println("WhiteTiger is jumping....");
		System.out.println("WhiteTiger defaultA   : "+defaultA);
		System.out.println("WhiteTiger privateA   : "+privateA); //ERROR- 
		System.out.println("WhiteTiger protectedA : "+protectedA);
		System.out.println("WhiteTiger publicA    : "+publicA);
	}
	
	void roar(Tiger t) {
		System.out.println("WhiteTiger is jumping....");
		System.out.println("WhiteTiger defaultA   : "+t.defaultA);
		System.out.println("WhiteTiger privateA   : "+t.privateA); //ERROR- 
		System.out.println("WhiteTiger protectedA : "+t.protectedA);
		System.out.println("WhiteTiger publicA    : "+t.publicA);
	}
}
