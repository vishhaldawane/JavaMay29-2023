package jungle.cave;

//writing a public class does not mean the contents are public 
public class Tiger {
	public Tiger() {
		
	}
    public void jump() {
    	
		System.out.println("Tiger is jumping....");
	}
}

