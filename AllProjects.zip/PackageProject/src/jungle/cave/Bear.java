package jungle.cave;

public class Bear {
	public void eatHoney() {
		System.out.println("Bear is eating the honey...");
	}
}
