import java.time.LocalDate;

class Employee {
	//basic,hra,da
	//void operator +() { }
	//void add() { }  void subtract(){} void divide() { }
}
// Employee e1,  e2, e3 = e1.add(e2).subtract(e4).divide(e5);
// e1+e2-e4/e5 Objects in math expression
public class OverridingTest {
	public static void main(String[] args) {
		
		System.out.println(10+20+" addition of : "+10+20);
		
		SavingsAccount savings = new SavingsAccount();
		savings.setSavingsAccount(50000);
		savings.withdraw(4000);
		System.out.println("-------------");
		FixedDepositAccount fd = new FixedDepositAccount();
		fd.setFixedAccount(50000, LocalDate.of(2023, 05, 31));
		fd.withdraw(4000);
	}
}
class SavingsAccount {
	float balance;
	void setSavingsAccount(float initialBalance) {
		balance = initialBalance;
	}
	void withdraw(float amountToWithdraw) {
		if(amountToWithdraw < (balance-5000)) {
			balance -= amountToWithdraw;
			System.out.println("Savings Withdrawn : "+amountToWithdraw);
		}
		else 
			System.out.println("Cannot withdraw...");
		}
}
class FixedDepositAccount extends SavingsAccount {
	LocalDate accountMaturity;
	void setFixedAccount(float initialBalance, LocalDate md) {
		balance = initialBalance;
		accountMaturity = md;
	}
	void withdraw(float amountToWithdraw) { //	OVERRIDING AS PER TEH RULE OF THE CHILD'S LOGIC
		if(amountToWithdraw <= balance && accountMaturity.equals(LocalDate.now())) {
			balance -= amountToWithdraw;
			System.out.println("FD Withdrawn : "+amountToWithdraw);
		}
		else 
			System.out.println("Account not yet matured...");
		}
}
