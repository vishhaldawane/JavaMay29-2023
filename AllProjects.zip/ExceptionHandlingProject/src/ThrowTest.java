
public class ThrowTest {
	public static void main(String[] args) {
		
		System.out.println("line1");
		System.out.println("line2");
		System.out.println("line3");
		System.out.println("line4");
		System.out.println("line5");
		
		if(10>20)
		    throw new RuntimeException("kuchh to hua....");
		
		System.out.println("line6");
		System.out.println("line7");
		System.out.println("line8");
		
		if(5>2)
			throw new RuntimeException("aur kuchh to hua....");
		
		System.out.println("line9");
		System.out.println("line10");
		
	}
}
