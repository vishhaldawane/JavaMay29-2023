//https://github.com/vishhaldawane/JavaMay29-2023
public class FunctionTest {
	public static void main(String[] args) {
		
		String myName="Jack";
		String city="New Mumbai";
		char gender='M';
		
		System.out.println("Hello I am "+myName+" and I stays at "+city+" my gender is "+gender);
		
		Teacher teacher = new Teacher();
		teacher.cleanWhiteBoard();
		teacher.gotoLocation(45.3f, 90.7f);
		float foundAvg = teacher.calculateAverage(10, 11, 4);
		System.out.println("Average : "+foundAvg);
		
		double dist = teacher.whatIsTheDistanceBetweenTheEarthAndTheSun();
		System.out.println("Distance is : "+dist);
		
		System.out.println("----------------");
		
		Photographer pg = new Photographer();
		pg.zoomIn();
		pg.click(500);
		int cost = pg.amount(300,50);
		System.out.println("Cost of album : "+cost);
		
		String type = pg.typeOfAlbum();
		System.out.println("Type of album : "+type);
		
		
		
	}
}
class Teacher {
	//1. function without arguments and without return value
	void cleanWhiteBoard() { //rows columns
		System.out.println("1st type : clearing white board...");
	}
	
	//2. function with arguments BUT without return value
	void gotoLocation(float longitude, float lattitude) {
		System.out.println("Teacher is going to the location of longitude : "+longitude+" and lattitude : "+lattitude);
	}
	
	//3. function with arguments AND with return value
	float calculateAverage(int x, int y, int z) {
		System.out.println("Teacher is calculating average of "+x+","+y+" and "+z);
		float avg = (float) (x+y+z) / 3;
		return avg;
	}
	
	//4. function without arguments BUT with return value
	double whatIsTheDistanceBetweenTheEarthAndTheSun() {
		float SPEED_OF_LIGHT=186000.519f;
		float TIME_TO_REACH_ON_EARTH=480.0f; //seconds
		double DISTANCE = (double)SPEED_OF_LIGHT * TIME_TO_REACH_ON_EARTH;
		return DISTANCE;
	}
}


class Photographer
{
	void zoomIn() {
		System.out.println("Zoom in...");
	}
	void click(int numberOfPics) {
		System.out.println("clicking ..."+numberOfPics);
	}
	int amount(int numberOfPics, int pricePerPic) {
		System.out.println("Calculating album cost...");
		return numberOfPics * pricePerPic;
	}
	String typeOfAlbum() {
		System.out.println("Returning album type....");
		return "its a marriage album";
	}
}















