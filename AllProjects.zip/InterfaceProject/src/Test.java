import java.util.Iterator;

public class Test {

	public static void main(String[] args) {
		
		Flight flight[]= new Flight[100000];
		
		for (int i = 0; i < 100000; i++) {
			flight[i] = new Flight(i);
		}

	}

}
class Flight {
	int flightNumber;
	String flightName;
	String source;
	String dest;
	public Flight(int i) {
		System.out.println(i+" Flight constructed....");

	}
	
}